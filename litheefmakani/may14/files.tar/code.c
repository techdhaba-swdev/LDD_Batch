#include<stdio.h>


int main(){
	int num1,num2;
	//float avg;
	printf("enter the num1 value:");
	scanf("%d",&num1);
	printf("enter the num2 value:");
	scanf("%d",&num2);
	float avg=(float)(num1+num2)/2;
	printf("avg value of num1 and num2 is : %f\n",avg);
	return 0;
}
