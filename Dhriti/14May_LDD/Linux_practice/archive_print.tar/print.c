#include<stdio.h>

int main()
{
	int a=4;
	int b=6;

	printf("The first number is: %d\n",a);
	 printf("The second number is: %d\n",b);
         
	 
        printf("Average: %f\n", (float)(a+b)/2);
	 return 0;
}

