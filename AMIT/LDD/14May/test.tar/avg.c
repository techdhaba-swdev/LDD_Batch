#include<stdio.h>

int main()
{
	float a,b;
	float avg;
	printf("enter the first number:");
	scanf("%f",&a);
	printf("enter the second number:");
        scanf("%f",&b);
        avg=(a+b)/2;
	printf("Average:%f\n",avg);

	return 0;
}

