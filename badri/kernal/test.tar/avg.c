#include <stdio.h>

int main()
	{
		int num1 , num2 ;
	       float avg;
		printf("enter two numbers \n");
		scanf("%d%d",&num1 , &num2);
		avg = (num1 + num2)/2;
		printf("result : %f",avg);
	}






































	
