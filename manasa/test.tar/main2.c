#include "main.h"

int main() {
	printf("add is %d", add(4,5));
	printf("sub is %d", sub(4,5));
	return 0;
}
