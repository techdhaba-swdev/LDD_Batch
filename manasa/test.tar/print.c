#include<stdio.h>
#include "print.h"
void print_n_value(int num) {
	for(int Cnt_o;Cnt<num;Cnt++) {
		printf("cnt %d \n",Cnt);
	}
}
