#include<stdio.h>
void hello()
{
	printf("welcome to my_lib!\n");
}
