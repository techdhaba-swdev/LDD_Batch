#include<stdio.h>
#include "math.h"
//int add(int x, int y);

int main() {
	printf(" add is %d\n", add(5,4));
	return 0;
}
/*
 int add(int x, int y) {
 return x+y;
 }*/
