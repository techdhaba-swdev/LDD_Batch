#include<stdio.h>
#include "lib.h"
void hello()
{
	printf("welcomr to library!\n");
}

