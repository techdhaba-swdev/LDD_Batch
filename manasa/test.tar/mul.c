int mul2(int x, int y)

{

return x+y;

} int mul3(int x, int y, int z)

{

return x+y+z;

}

int mul4(int x, int y, int z,int a)

{

return x*y*z*a;
}

