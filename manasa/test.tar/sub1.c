int sub(intx, int y) {
	return x-y;
}

