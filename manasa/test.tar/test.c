#include<stdio.h>
#include"print.h"
int main() {
	printf("hello \n");
	print_n_value(10);
	return 0;
}
