void main(void) {
	char password[10];
	puts("Manasa123456:");
	gets(password);
}
