#include "print_message.h"

void print_message(const char *message) {
    printf("%s", message);
}
