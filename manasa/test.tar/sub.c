int sub2(int x, int y)

{

return x+y;

} int sub3(int x, int y, int z)

{

return x+y+z;

}

int sub4(int x, int y, int z,int a)

{

return x-y-z-a;
}
