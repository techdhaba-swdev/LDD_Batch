#include <stdio.h>
#include "example.h"
void print_message() {
	printf("Hello, good morning manasa!\n");
}
