#include<stdio.h>
int adding(int a, int b) {
	return a +b;
}
