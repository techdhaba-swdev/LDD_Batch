#include<stdio.h>

int main(){

	int a=20,b=10;
	printf("division is %d\n",a/b);
	return 0;

}

