#include<stdio.h>

int main(){

	int a=20,b=10;
	printf("multiplicaton is %d\n",a*b);
	return 0;

}

